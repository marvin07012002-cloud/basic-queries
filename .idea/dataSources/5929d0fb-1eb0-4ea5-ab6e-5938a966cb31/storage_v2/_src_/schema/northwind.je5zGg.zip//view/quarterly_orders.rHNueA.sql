create definer = root@localhost view `quarterly orders` as
select distinct `northwind`.`customers`.`CustomerID`  AS `CustomerID`,
                `northwind`.`customers`.`CompanyName` AS `CompanyName`,
                `northwind`.`customers`.`City`        AS `City`,
                `northwind`.`customers`.`Country`     AS `Country`
from (`northwind`.`customers` join `northwind`.`orders`
      on ((`northwind`.`customers`.`CustomerID` = `northwind`.`orders`.`CustomerID`)))
where (`northwind`.`orders`.`OrderDate` between '1997-01-01' and '1997-12-31');

