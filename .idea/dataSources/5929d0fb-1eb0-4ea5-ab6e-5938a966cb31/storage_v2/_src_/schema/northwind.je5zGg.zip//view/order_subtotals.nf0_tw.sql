create definer = root@localhost view `order subtotals` as
select `northwind`.`order details`.`OrderID`                               AS `OrderID`,
       sum(((((`northwind`.`order details`.`UnitPrice` * `northwind`.`order details`.`Quantity`) *
              (1 - `northwind`.`order details`.`Discount`)) / 100) * 100)) AS `Subtotal`
from `northwind`.`order details`
group by `northwind`.`order details`.`OrderID`;

