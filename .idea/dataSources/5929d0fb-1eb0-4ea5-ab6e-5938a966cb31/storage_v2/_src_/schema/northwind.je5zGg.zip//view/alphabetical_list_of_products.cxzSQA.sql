create definer = root@localhost view `alphabetical list of products` as
select `northwind`.`products`.`ProductID`       AS `ProductID`,
       `northwind`.`products`.`ProductName`     AS `ProductName`,
       `northwind`.`products`.`SupplierID`      AS `SupplierID`,
       `northwind`.`products`.`CategoryID`      AS `CategoryID`,
       `northwind`.`products`.`QuantityPerUnit` AS `QuantityPerUnit`,
       `northwind`.`products`.`UnitPrice`       AS `UnitPrice`,
       `northwind`.`products`.`UnitsInStock`    AS `UnitsInStock`,
       `northwind`.`products`.`UnitsOnOrder`    AS `UnitsOnOrder`,
       `northwind`.`products`.`ReorderLevel`    AS `ReorderLevel`,
       `northwind`.`products`.`Discontinued`    AS `Discontinued`,
       `northwind`.`categories`.`CategoryName`  AS `CategoryName`
from (`northwind`.`categories` join `northwind`.`products`
      on ((`northwind`.`categories`.`CategoryID` = `northwind`.`products`.`CategoryID`)))
where (`northwind`.`products`.`Discontinued` = 0);

